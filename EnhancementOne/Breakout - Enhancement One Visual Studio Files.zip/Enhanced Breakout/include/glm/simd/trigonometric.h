/// @ref simd
/// @file glm/simd/trigonometric.h

#pragma once

#if GLM_ARCH & GLM_ARCH_SSE2_BIT

#endif//GLM_ARCH & GLM_ARCH_SSE2_BIT

